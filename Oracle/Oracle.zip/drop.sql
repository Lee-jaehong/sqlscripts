drop table tbl_bookrent;
drop table book_member;
drop table tbl_book;
drop sequence book_seq;
drop sequence rent_seq;